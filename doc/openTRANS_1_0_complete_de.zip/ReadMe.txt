
  Name:             openTRANS v. 1.0.zip
  Date:             10.01.2003
  Authors:          Oliver Kelkar   (olk),  Fraunhofer IAO Stuttgart
                    Volker Schmitz  (stz),  Universitaet Essen BLI
                    Sven Sprandel   (spr),  Fraunhofer IAO Stuttgart
                    Stefan Kubitzky (kub),  Universitaet Essen BLI
			
  Copyright 2003, All Rights Reserved
  Fraunhofer IAO Stuttgart, Universitaet Essen BLI
  
  openTRANS:
  more infos and full specification: http://www.opentrans.org
  e-mail contact: authors@opentrans.org


CONTENT:
========

This file contains all documents of openTRANS v. 1.0:
 - Documentation in english and german
 - DTDs (document type definitions)
 - Examples for DTDs
 - XML-Schema (XSD) in modular form
   -> document schemas include other schemas (espacially codes)
 - Examples for XSD in modular form
 - XML-Schema (XSD) in complete form (all in one)
   -> only one XSD per document is used
 - Examples for XSD in complete form (all in one)

DISCLAIMER:
===========

Fraunhofer IAO and the University of Essen hereby grant you the permanent, non-exclusive, royalty-free, world-wide right and the license to use the openTRANS� Specification and to use, copy, publish and distribute same in compliance with the copyrights indicated in the specification. Fraunhofer IAO and the University of Essen hereby declare themselves willing to grant you a royalty-free license, in accordance with copyright laws, for the implementation and use of the openTRANS� Tags and Guidelines for the creation of computer programs in accordance with these guidelines. This license is granted under the condition that you do not assert any copyright claims vis-a-vis Fraunhofer IAO and the University of Essen BLI or other companies for their implementation. Fraunhofer IAO and the University of Essen BLI expressly retain all other rights to the material and the subject of the specifications. Fraunhofer IAO and the University of Essen BLI expressly decline any type of guarantee for the specification, including guarantees that this specification or its implementation does not infringe on the rights of third parties. If you publish, copy or distribute this specification, it must carry a copyright reference. If, however, you alter the specification, the name of the altered specification may under no circumstances contain the term "openTRANS� " and the following reference must be contained in the amended version: "Parts of this specification are based on the openTRANS� Standard V1.0 (Copyright � 2000-2001 Fraunhofer IAO and University of Essen BLI").

We reserve the right to make changes to the information contained in this document without prior notice.